class Address{
    public street:string = "";
    public house_number:number = null;
    public floor:number = null;
    public PrintAddress():void
    {
        //document.write( "Name: " + this.fullname + ", Age: " + this.age);
        document.write( `${this.street},  ${this.house_number} / ${this.floor}<br/>`);
    }
}

class Person{
    public fullname:string;
    public age:number; 
    public address:Address = new Address();

    public Print():void
    {
        //document.write( "Name: " + this.fullname + ", Age: " + this.age);
        document.write( `Name: ${this.fullname}, Age: ${this.age} <br/>`);
        this.address.PrintAddress();
    }

}


/*
let person1:Person = new Person();
let person2:Person = person1;

var name = prompt("Enter");
person1.fullname = "Saar";
person1.age = 40;
person1.Print();

person2.fullname = "Yona";
person2.age = 60;
person1.Print();

person1.address.floor = 5;
person1.address.house_number = 7;
person1.address.street = "Shenkin";
*/
