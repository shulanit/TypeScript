$(document).ready(function(){
    var person1 = new Person();
    var person2 = person1;
    person1.fullname = "Saar";
    person1.age = 40;
    person1.Print();
    person2.fullname = "Yona";
    person2.age = 60;
    person1.address.floor = 5;
    person1.address.house_number = 7;
    person1.address.street = "Shenkin";
    person1.Print();
});