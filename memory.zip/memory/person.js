var Address = /** @class */ (function () {
    function Address() {
        this.street = "";
        this.house_number = null;
        this.floor = null;
    }
    Address.prototype.PrintAddress = function () {
        //document.write( "Name: " + this.fullname + ", Age: " + this.age);
        document.write(this.street + ",  " + this.house_number + " / " + this.floor + "<br/>");
    };
    return Address;
}());
var Person = /** @class */ (function () {
    function Person() {
        this.address = new Address();
    }
    Person.prototype.Print = function () {
        //document.write( "Name: " + this.fullname + ", Age: " + this.age);
        document.write("Name: " + this.fullname + ", Age: " + this.age + " <br/>");
        this.address.PrintAddress();
    };
    return Person;
}());
/*
let person1:Person = new Person();
let person2:Person = person1;

var name = prompt("Enter");
person1.fullname = "Saar";
person1.age = 40;
person1.Print();

person2.fullname = "Yona";
person2.age = 60;
person1.Print();

person1.address.floor = 5;
person1.address.house_number = 7;
person1.address.street = "Shenkin";
*/
