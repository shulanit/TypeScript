var Person = /** @class */ (function () {
    function Person() {
    }
    Person.prototype.Print = function () {
        //document.write( "Name: " + this.fullname + ", Age: " + this.age);
        document.write("Name: " + this.fullname + ", Age: " + this.age + " <br/> ");
    };
    return Person;
}());

let person1 = new Person();
let person2 = person1;

person1.fullname = "Saar";
person1.age = 40;
person1.Print();

person2.fullname = "Yona";
person2.age = 60;
person1.Print();
