var Car = /** @class */ (function () {
    function Car(manufacturerField, modelField, wheel) {
        if (manufacturerField === void 0) { manufacturerField = ""; }
        if (modelField === void 0) { modelField = ""; }
        if (wheel === void 0) { wheel = new Wheel(); }
        this.manufacturerField = manufacturerField;
        this.modelField = modelField;
        this.wheelField = wheel;
    }
    Car.prototype.setManufacturer = function (value) {
        this.manufacturerField = value;
    };
    Car.prototype.getManufacturer = function () {
        return this.manufacturerField;
    };
    Car.prototype.setModel = function (value) {
        this.modelField = value;
    };
    Car.prototype.getModel = function () {
        return this.modelField;
    };
    Car.prototype.setWheel = function (value) {
        this.wheelField = value;
    };
    Car.prototype.getWheel = function () {
        return this.wheelField;
    };
    Car.prototype.print = function () {
        document.write("Car manufacturer: " + this.manufacturerField + "<br/>");
        document.write("Car Model: " + this.modelField + "<br/>");
        this.wheelField.print();
    };
    return Car;
}());
var w = new Wheel();
var car = new Car("BMW", "S4", w);
car.print();
