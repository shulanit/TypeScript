class Wheel{
    private diameterField: number;
    private colorField: string;

    public constructor(diameter: number = 10, color: string = "Black"){
        this.diameterField = diameter;
        this.colorField = color;
    }

    public setDiameter( value:number){
        this.diameterField = value;
    }
    public getDiameter():number{
        return this.diameterField;
    }
    public setColor( value:string){
        this.colorField = value;
    }
    public getColor():string{
        return this.colorField;
    }

    public print():void {
        document.write("Wheel Diameter: " + this.diameterField + "<br/>");
        document.write("Wheel Color: " + this.colorField + "<br/>");
    }
}

/*
let w = new Wheel();

console.log( w.getColor() );
*/