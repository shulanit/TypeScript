var Wheel = /** @class */ (function () {
    function Wheel(diameter, color) {
        if (diameter === void 0) { diameter = 10; }
        if (color === void 0) { color = "Black"; }
        this.diameterField = diameter;
        this.colorField = color;
    }
    Wheel.prototype.setDiameter = function (value) {
        this.diameterField = value;
    };
    Wheel.prototype.getDiameter = function () {
        return this.diameterField;
    };
    Wheel.prototype.setColor = function (value) {
        this.colorField = value;
    };
    Wheel.prototype.getColor = function () {
        return this.colorField;
    };
    Wheel.prototype.print = function () {
        document.write("Wheel Diameter: " + this.diameterField + "<br/>");
        document.write("Wheel Color: " + this.colorField + "<br/>");
    };
    return Wheel;
}());
/*
let w = new Wheel();

console.log( w.getColor() );
*/ 
