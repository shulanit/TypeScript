class Car{
    private manufacturerField: string;
    private modelField: string;
    private wheelField: Wheel;

    public constructor(manufacturerField: string = "", modelField: string = "" , wheel:Wheel = new Wheel() ){
        this.manufacturerField = manufacturerField;
        this.modelField = modelField;
        this.wheelField = wheel;
    }

    public setManufacturer( value:string){
        this.manufacturerField = value;
    }
    public getManufacturer():string{
        return this.manufacturerField;
    }
    public setModel( value:string){
        this.modelField = value;
    }
    public getModel():string{
        return this.modelField;
    }

    public setWheel( value:Wheel){
        this.wheelField = value;
    }
    public getWheel():Wheel{
        return this.wheelField;
    }

    public print():void {
        document.write("Car manufacturer: " + this.manufacturerField + "<br/>");
        document.write("Car Model: " + this.modelField + "<br/>");
        this.wheelField.print();
    }
}


let w = new Wheel();
let car = new Car("BMW","S4",w);
car.print();
