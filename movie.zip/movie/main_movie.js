window.onload = function(){
    var movie1 = new movies("globus-max",11,23,100);
    var movie2 = new movies("yes-planet",9,22,80);
    

    document.write( movie1.print() );
    document.write( movie2.print() );
    
}