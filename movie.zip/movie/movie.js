var movies = /** @class */ (function () {
    function movies(name, open_hour, close_hour, number_cher) {
        if (open_hour === void 0) { open_hour = 6; }
        if (close_hour === void 0) { close_hour = 23; }
        this.name = name;
        this.open_hour = open_hour;
        this.close_hour = close_hour;
        this.number_cher = number_cher;
    }
    movies.prototype.openHourse = function () {
        var hourse = this.close_hour - this.open_hour;
        return hourse;
    };
    movies.prototype.print = function () {
        var html = "";
        html += "Name: " + this.name + " <br/>";
        html += "open_hour: " + this.number_cher + " <br/>";
        html += "close_hour: " + this.open_hour + " <br/>";
        html += "number_cher: " + this.close_hour + " <br/>";
        return html;
    };
    return movies;
}());
