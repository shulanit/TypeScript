class movies{
    public name:string;
    public number_cher:number;
    public open_hour:number;
    public close_hour:number;
    
    public constructor(name:string,open_hour:number = 6,close_hour:number = 23,number_cher?:number)
    {
        this.name = name;
        this.open_hour = open_hour;
        this.close_hour = close_hour;
        this.number_cher = number_cher;
    }


    public openHourse():number
    {
        var hourse = this.close_hour-this.open_hour;
        return hourse;
    }

    public print():string
    {
        let html:string = "";
        html += `Name: ${this.name} <br/>`;
        html += `open_hour: ${this.number_cher} <br/>`;
        html += `close_hour: ${this.open_hour} <br/>`;
        html += `number_cher: ${this.close_hour} <br/>`;

        return html;
    }

}
